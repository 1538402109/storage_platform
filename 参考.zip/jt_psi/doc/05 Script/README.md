需要安装git，用git的Git Bash打开，例如：bash build_All.sh

build_All.sh 生成PC和移动版完整的发布版

build_fast_All.sh 快速生成PC和移动版完整的发布版

build_help.sh 生成帮助文档