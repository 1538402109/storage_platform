<?php

namespace Home\DAO;

/**
 * ID DAO
 *
 * @author JIATU
 */
class IdGenDAO extends PSIBaseExDAO {
}