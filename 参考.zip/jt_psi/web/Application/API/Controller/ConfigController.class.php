<?php
namespace API\Controller;

use Think\Controller;

/**
 *
 * @author taoyj
 *        
 */
class ConfigController extends BaseController 
{

  
    public function index()
    {
        if (IS_GET) {
            
        }
    }
}
